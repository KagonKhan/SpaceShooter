Thanks for downloading our font.

This is limited character demo version.
if you would like to consider using it for commercial projects. 
please visit 

http://www.studiotypo.com/

Test Page
http://www.studiotypo.com/test/aspace_testscreen.html

Thanks